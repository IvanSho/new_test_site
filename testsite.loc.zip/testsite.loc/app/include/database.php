<?php

    $link = mysqli_connect('localhost', 'root', 'root', 'test_site_to');
//
//    if(mysqli_errno()){
//        echo 'Ошибка подключения';
//    } else {
//        echo 'ААААААААААААААА';
//    }
